package com.cognizant.fraudmanagementsystem;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FraudManagementSystemApplicationTests {

}
