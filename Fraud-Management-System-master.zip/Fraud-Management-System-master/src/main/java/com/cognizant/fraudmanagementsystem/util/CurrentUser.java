package com.cognizant.fraudmanagementsystem.util;

public class CurrentUser {
    public static String id = "";
    public static String type = "";
}
